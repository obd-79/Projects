public enum VehicleStatus {
    AVAILABLE,
    BOOKED,
    RENTED
}