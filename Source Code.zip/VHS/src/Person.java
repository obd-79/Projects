public class Person {
    int id;
    String name;
    String phoneNumber;
    String emailAddress;
    String address;
    static int lastId;
}
