public class TransportTrucks extends Truck {
    public TransportTrucks(String plateNumber, int numberOfTires, double dailyFee, double loadingCap) {
        super(plateNumber, numberOfTires, dailyFee, loadingCap);
    }
}