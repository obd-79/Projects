public class SmallTrucks extends Truck {
    public SmallTrucks(String plateNumber, int numberOfTires, double dailyFee, double loadingCap) {
        super(plateNumber, numberOfTires, dailyFee, loadingCap);
    }
}
