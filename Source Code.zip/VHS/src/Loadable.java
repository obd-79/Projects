public interface Loadable {
    void loadMe(double additionalLoad) throws OverWeightException;
}