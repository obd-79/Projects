public class Admin extends Person {
    String userName;
}
